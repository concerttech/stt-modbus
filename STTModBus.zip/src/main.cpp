/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 Concert Technologies.
  * All rights reserved.
  *
  *
  ******************************************************************************
*/

#include <iostream>
#include <mosquitto.h>
#include <gpiod.h>
#include <termios.h>
#include <unistd.h>
#include <sys/time.h>

#include "modbus.h"
#include "mqtt.h"

// Definições para comunicação serial
#define SERIAL_PORT 2           // Porta serial (1 para porta A e 2 para porta B)
#define BAUDRATE B9600          // Taxa de transmissão
#define PARITY 'N'              // Sem paridade
#define DATA_BITS 8             // 8 bits de dados
#define STOP_BITS 1             // 1 bit de parada

// Definição das portas de IO
/*----------Serial A------------*/
// SODIMM 133
#define SERIALA_DE_CHIP         3
#define SERIALA_DE_LINE         24
// SODIMM 206
#define SERIALA_H_F_CHIP        0
#define SERIALA_H_F_LINE        0
// SODIMM 208
#define SERIALA_TERM_TX_CHIP    0
#define SERIALA_TERM_TX_LINE    1
// SODIMM 210
#define SERIALA_TERM_RX_CHIP    0
#define SERIALA_TERM_RX_LINE    5
// SODIMM 212
#define SERIALA_SLR_CHIP        0
#define SERIALA_SLR_LINE        6
/*----------Serial B------------*/
// SODIMM 141
#define SERIALB_DE_CHIP         1
#define SERIALB_DE_LINE         7
// SODIMM 216
#define SERIALB_H_F_CHIP        0    
#define SERIALB_H_F_LINE        7
// SODIMM 218
#define SERIALB_TERM_TX_CHIP    0 
#define SERIALB_TERM_TX_LINE    8
// SODIMM 220
#define SERIALB_TERM_RX_CHIP    3 
#define SERIALB_TERM_RX_LINE    3
// SODIMM 222
#define SERIALB_SLR_CHIP        3
#define SERIALB_SLR_LINE        1

/*-------------------------------------------------*/
/*
  @brief Set the IO value

  OPen the chip, poen the linha, configure line as output
  set IO value. 

  @param chip_num gpiochip number
  @param line_num line number
  @param value Value to be set

  @return return the error code (0 -> NoErro)
*/
/*-------------------------------------------------*/
int Set_IO (char chip_num, char line_num, char value) {

    const char *chipStringName="gpiochip%d";
    char chipName[15];
    struct gpiod_chip *chip;
    struct gpiod_line *line;

    // Chip name
    sprintf (chipName, chipStringName, chip_num);

    // Open GPIO chip
    chip = gpiod_chip_open_by_name(chipName); 
    // Open the GPIO line
    line = gpiod_chip_get_line(chip, line_num);  
    // Open line for output
    gpiod_line_request_output(line, "GPIO Line", 0);
    // Set line value
    gpiod_line_set_value(line, value);
  
    // Realease Line and chip
    gpiod_line_release(line);
    gpiod_chip_close(chip);

    return 0;
    
} // Set_IO

/*-------------------------------------------------*/
/*
  @brief Config the IO pins for the serial RS 485/422

  Set the port as half-duplex, conect the terminator resitor.
 
  @return return the error code (0 -> NoErro)
*/
/*-------------------------------------------------*/
int ConfigIO(uint8_t porta) {

    if (porta == 1) {
        // Set as hal-duplex
        Set_IO (SERIALA_H_F_CHIP, SERIALA_H_F_LINE, 1);

        // Turn-on the terminator resistor 
        Set_IO (SERIALA_TERM_TX_CHIP, SERIALA_TERM_TX_LINE,1);
        Set_IO (SERIALA_TERM_RX_CHIP, SERIALA_TERM_RX_LINE,1);
        return 0;
    }
    else if (porta==2) {
        // Set as hal-duplex
        Set_IO (SERIALB_H_F_CHIP, SERIALB_H_F_LINE, 1);

        // Turn-on the terminator resistor 
        Set_IO (SERIALB_TERM_TX_CHIP, SERIALB_TERM_TX_LINE,1);
        Set_IO (SERIALB_TERM_RX_CHIP, SERIALB_TERM_RX_LINE,1);
        return 0;
    }
    
    return -1;
    
} // ConfigIO

/**
 *  @brief Publish the partionData0 in MQTT 
 *  @param mosq MQTT object
 *  @param Partition0Data Data to be published
 *  
 */
void publishPartition0Data(struct mosquitto *mosq, struct Partition0Data *data) {

    char payload[1024]; // Ajuste o tamanho conforme necessário
    int payloadLength = 0;
    char topic[100];
    int i;

    // Constrói o tópico para a partição 0
    snprintf(topic, sizeof(topic), MQTT_TOPIC_PARTITION_0);

    // Prepara o payload com os dados da estrutura no formato "Nome:Valor"
    payloadLength = snprintf(payload, sizeof(payload),
        "{ "
        "\"MaxVoltage\":%u,"
        "\"RatedCurrent\":%u,"
        "\"RatedDischargeCurrent\":%u,"
        "\"ProductType\":%u,"
        "\"ProductSpecification\":\"%s\","
        "\"SoftwareVersion\":%u,"
        "\"HardwareVersion\":%u,"
        "\"ProductSerialNumber\":%u,"
        "\"DeviceAddress\":%u"
        "}",
        data->MaxVoltage, 
        data->RatedCurrent, 
        data->RatedDischargeCurrent, 
        data->ProductType, 
        data->ProductSpecification,
        data->SoftwareVersion,
        data->HardwareVersion,
        data->ProductSerialNumber,
        data->DeviceAddress
    );

    if (payloadLength < 0) {
        fprintf(stderr, "Erro ao formatar payload para partição 0\n");
        return; // Não tenta publicar dados inválidos
    }

    // Publica os dados no tópico MQTT
    mosquitto_publish(mosq, NULL, topic, payloadLength, payload, 0, 0);
    printf("Publicado no tópico %s, payload: %s\n", topic, payload);

} // publishPartition0Data


/**
 *  @brief Publish the partionData1 in MQTT 
 *  @param mosq MQTT object
 *  @param Partition1Data Data to be published
 *  
 */
void publishPartition1Data(struct mosquitto *mosq, struct Partition1Data *data) {
    char payload[2048]; // Ajuste o tamanho conforme necessário
    int payloadLength = 0;
    char topic[100];

    // Constrói o tópico para a partição 1
    snprintf(topic, sizeof(topic), MQTT_TOPIC_PARTITION_1);

    // Prepara o payload com os dados da estrutura no formato "Nome:Valor"
/*    
    payloadLength = snprintf(payload, sizeof(payload),
    "LoadState:%u,ChargeState:%u,BatterySOC:%u,BatteryVoltage:%u,ChargeCurrent:%u,DeviceTemperature:%u,BatteryTemperature:%u,"
    "LoadVoltage:%u,LoadCurrent:%u,LoadPower:%u,SolarPanelVoltage:%u,SolarPanelCurrent:%u,ChargePower:%u,LoadOnOff:%u,"
    "MinBatteryVoltageToday:%u,MaxBatteryVoltageToday:%u,MinChargeCurrentToday:%u,MaxChargeCurrentToday:%u,"
    "MaxChargePowerToday:%u,MaxDischargePowerToday:%u,DischargeAmpereHourToday:%u,GeneratingCapacityToday:%u,"
    "ElectricityConsumedToday:%u,TotalBatteryChargeTimes:%u,TotalBatteryChargeAH:%u,TotalBatteryDischargeAH:%u,"
    "TotalGeneratingCapacity:%u,MinBatteryTemperatureToday:%u,TotalLoadOperationTime:%u,LastLoadTurnOnTime:%u,"
    "LastLoadTurnOffTime:%u,LightingIndex:%u,EnergyConsumption:%u,SystemHealthIndex:%u",
    data->LoadState, data->ChargeState, data->BatterySOC, data->BatteryVoltage, data->ChargeCurrent,
    data->DeviceTemperature, data->BatteryTemperature, data->LoadVoltage, data->LoadCurrent, data->LoadPower,
    data->SolarPanelVoltage, data->SolarPanelCurrent, data->ChargePower, data->LoadOnOff,
    data->MinBatteryVoltageToday, data->MaxBatteryVoltageToday, data->MinChargeCurrentToday,
    data->MaxChargeCurrentToday, data->MaxChargePowerToday, data->MaxDischargePowerToday,
    data->DischargeAmpereHourToday, data->GeneratingCapacityToday, data->ElectricityConsumedToday,
    data->TotalBatteryChargeTimes, data->TotalBatteryChargeAH, data->TotalBatteryDischargeAH,
    data->TotalGeneratingCapacity, data->MinBatteryTemperatureToday, data->TotalLoadOperationTime,
    data->LastLoadTurnOnTime, data->LastLoadTurnOffTime, data->LightingIndex, data->EnergyConsumption, data->SystemHealthIndex
);
*/
payloadLength = snprintf(payload, sizeof(payload),
        "{ "
        "\"LoadState\":%u,"
        "\"ChargeState\":%u,"
        "\"Alarme_Failure\":%u," // Alarme_Failure (sem aspas, é número)
        "\"BatterySOC\":%u," // SOC é %d [cite: 69]
        "\"BatteryVoltage\":%.1f," // Multiplicador 0.1 [cite: 69]
        "\"ChargeCurrent\":%.2f," // Multiplicador 0.01 [cite: 69]
        "\"DeviceTemperature\":%d," // Temperaturas podem ser negativas (sem aspas) [cite: 69]
        "\"BatteryTemperature\":%d," // Temperaturas podem ser negativas (sem aspas) [cite: 69]
        "\"LoadVoltage\":%.1f," // Multiplicador 0.1 [cite: 70]
        "\"LoadCurrent\":%.2f," // Multiplicador 0.01 [cite: 72]
        "\"LoadPower\":%u," // Sem multiplicador [cite: 72]
        "\"SolarPanelVoltage\":%.1f," // Multiplicador 0.1 [cite: 72]
        "\"SolarPanelCurrent\":%.2f," // Multiplicador 0.01 [cite: 72]
        "\"ChargePower\":%u," // Sem multiplicador [cite: 72]
        "\"LoadOnOff\":%u," // Sem multiplicador [cite: 72]
        "\"MinBatteryVoltageToday\":%.1f," // Multiplicador 0.1 [cite: 75]
        "\"MaxBatteryVoltageToday\":%.1f," // Multiplicador 0.1 [cite: 75]
        "\"MaxChargeCurrentToday\":%.2f," // Multiplicador 0.01 [cite: 75]
        "\"MaxDischargeCurrentToday\":%.2f," // Multiplicador 0.01 [cite: 78]
        "\"MaxChargePowerToday\":%u," // Sem multiplicador [cite: 78]
        "\"MaxDischargePowerToday\":%u," // Sem multiplicador [cite: 81]
        "\"ChargeAmpereHourToday\":%u," // Sem multiplicador [cite: 81]
        "\"DischargeAmpereHourToday\":%u," // Sem multiplicador [cite: 81]
        "\"GeneratingCapacityToday\":%u," // Sem multiplicador (mas o protocolo diz /1000 para kWh) [cite: 81]
        "\"ElectricityConsumedToday\":%u," // Sem multiplicador (mas o protocolo diz /1000 para kWh) [cite: 81]
        "\"TotalOperatingDays\":%u," // Sem multiplicador [cite: 84]
        "\"TotalOverdischargetimes\":%u," // Sem multiplicador [cite: 84]
        "\"TotalBatteryChargeTimes\":%u," // Sem multiplicador [cite: 84]
        "\"TotalBatteryChargeAH\":%u," // Sem multiplicador (mas o protocolo mostra KAH) [cite: 88]
        "\"TotalBatteryDischargeAH\":%u," // Sem multiplicador (mas o protocolo mostra KAH) [cite: 88]
        "\"AccumulatedGeneratingCapacity\":%u," // Sem multiplicador (mas o protocolo mostra KWH) [cite: 88]
        "\"AccumulatedElectricityConsuption\":%u," // Sem multiplicador (mas o protocolo mostra KWH) [cite: 88]
        "\"DummyFailureAlarme\":%u," // Endereço 0x121 [cite: 195]
        "\"MaxBatteryTemperatureToday\":%u," // Endereço 0x123 [cite: 87]
        "\"MinBatteryTemperatureToday\":%u," // Endereço 0x124 [cite: 90]
        "\"TotalLoadOperationTime\":%u," // Endereço 0x125 [cite: 90]
        "\"Onduration\":%u," // Endereço 0x127 [cite: 90]
        "\"OffDuration\":%u," // Endereço 0x128 [cite: 90]
        "\"LightingIndex\":%u," // Endereço 0x129 [cite: 93]
        "\"EnergyConsumption\":%u," // Endereço 0x12A [cite: 93]
        "\"SystemHealthIndex\":%u," // Endereço 0x12B [cite: 93]
        "\"ChargeDurationOnDay\":%u," // Endereço 0x12C [cite: 93]
        "\"NightDuration\":%u" // Endereço 0x12D [cite: 93]
        "}",
        data->LoadState,
        data->ChargeState,
        data->Alarme_Failure,
        data->BatterySOC, // SOC %d
        data->BatteryVoltage / 10.0, // 0.1V [cite: 69]
        data->ChargeCurrent / 100.0, // 0.01A [cite: 69]
        data->DeviceTemperature, // %d
        data->BatteryTemperature, // %d
        data->LoadVoltage / 10.0, // 0.1V [cite: 70]
        data->LoadCurrent / 100.0, // 0.01A [cite: 72]
        data->LoadPower, // %u
        data->SolarPanelVoltage / 10.0, // 0.1V [cite: 72]
        data->SolarPanelCurrent / 100.0, // 0.01A [cite: 72]
        data->ChargePower, // %u
        data->LoadOnOff, // %u
        data->MinBatteryVoltageToday / 10.0, // 0.1V [cite: 75]
        data->MaxBatteryVoltageToday / 10.0, // 0.1V [cite: 75]
        data->MaxChargeCurrentToday / 100.0, // 0.01A [cite: 75]
        data->MaxDischargeCurrentToday / 100.0, // 0.01A [cite: 78]
        data->MaxChargePowerToday, // %u [cite: 78]
        data->MaxDischargePowerToday, // %u [cite: 81]
        data->ChargeAmpereHourToday, // %u [cite: 81]
        data->DischargeAmpereHourToday, // %u [cite: 81]
        data->GeneratingCapacityToday, // %u [cite: 81]
        data->ElectricityConsumedToday, // %u [cite: 81]
        data->TotalOperatingDays, // %u [cite: 84]
        data->TotalOverdischargetimes, // %u [cite: 84]
        data->TotalBatteryChargeTimes, // %u [cite: 84]
        data->TotalBatteryChargeAH, // %u [cite: 88]
        data->TotalBatteryDischargeAH, // %u [cite: 88]
        data->AccumulatedGeneratingCapacity, // %u [cite: 88]
        data->AccumulatedElectricityConsuption, // %u [cite: 88]
        data->DummyFailureAlarme, // %u [cite: 195]
        data->MaxBatteryTemperatureToday, // %u [cite: 87]
        data->MinBatteryTemperatureToday, // %u [cite: 90]
        data->TotalLoadOperationTime, // %u [cite: 90]
        data->Onduration, // %u [cite: 90]
        data->OffDuration, // %u [cite: 90]
        data->LightingIndex, // %u [cite: 93]
        data->EnergyConsumption, // %u [cite: 93]
        data->SystemHealthIndex, // %u [cite: 93]
        data->ChargeDurationOnDay, // %u [cite: 93]
        data->NightDuration // %u [cite: 93]
    );

    if (payloadLength < 0) {
        fprintf(stderr, "Erro ao formatar payload para partição 1\n");
        return; // Não tenta publicar dados inválidos
    }

    // Publica os dados no tópico MQTT
    mosquitto_publish(mosq, NULL, topic, payloadLength, payload, 0, 0);
    printf("Publicado no tópico %s, payload: %s\n", topic, payload);

} // publishPartition1Data

/**
  * @brief  The application entry point.
  * @retval int
  */
int main() {

    int serialPortFD;
    int rc;
    uint8_t systemVoltage, chargeCurrent;
    uint8_t batterySOC;
    uint8_t loadState, chargeState;
    uint8_t newDeviceAddress = 0x02;
    struct mosquitto *mosq = NULL;

    // Abre a porta serial
    serialPortFD = openSerialPort(SERIAL_PORT, BAUDRATE, PARITY, DATA_BITS, STOP_BITS);
    if (serialPortFD == -1) {
        printf("Falha ao abrir a porta serial.\n");
        return 1;
    }

    // Configura os pinos de IO da porta serial
    if (ConfigIO(SERIAL_PORT) == -1) {
        printf("Falha ao abrir configurar os pinos de IO.\n");
        return 1;
    }

    // Inicializa o MQTT
    if (InitMQTT(&mosq) != 0) {
        printf("Falha ao inicializar o MQTT.\n");
        closeSerialPort(serialPortFD);
        return 1;
    }

    // Loop do programa
    while (1) {

        // Le e publicaca dados da partição 0
        Partition0Data partition0Data;
        if (readPartition0Data(serialPortFD, &partition0Data)) {
            publishPartition0Data(mosq, &partition0Data);
        }

        // Le e publicaca dados da partição 1
        Partition1Data partition1Data;
        if (readPartition1Data(serialPortFD, &partition1Data)) {
            publishPartition1Data(mosq, &partition1Data);
        }

        // Process Mosquitto events
        rc = mosquitto_loop(mosq, -1, 1);
        if (rc != MOSQ_ERR_SUCCESS) {
            fprintf(stderr, "mosquitto_loop failed: %s\n", mosquitto_strerror(rc));
            break;
        }
        
        // Aguarda o próximo ciclo 
        sleep(10); 

    } // while

    // Fecha a porta serial
    closeSerialPort(serialPortFD);
    // Fecha a conexão MQTT
    CloseMQTT(mosq);

    return 0;

} // main


