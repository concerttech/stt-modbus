#include <stdio.h>
#include <stdint.h>
//#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <linux/serial.h>

#include "modbus.h"

#define SERIAL_PORT_STR "/dev/verdin-uart%d"

// Função para calcular o CRC16 (Modbus RTU)
uint16_t calculateCRC16(const uint8_t *data, uint16_t length) {
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < length; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 0x0001) {
                crc >>= 1;
                crc ^= 0xA001;
            } else {
                crc >>= 1;
            }
        }
    }
    return crc;
} // calculateCRC16

// Função para abrir a porta serial (Linux)
int openSerialPort(char port, int baudrate, char parity, int dataBits, int stopBits) {
    char msg[32];
    char portStr[32];
    int fd;

    // Cria o /dev da porta
    sprintf (portStr, SERIAL_PORT_STR, port);

    fd = open(portStr, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (fd == -1) {
        sprintf(msg, "Erro ao abrir a porta %s", port);
        perror(msg);
        return -1;
    }

    struct termios tty;
    if (tcgetattr(fd, &tty) != 0) {
        perror("Erro ao obter atributos da porta serial");
        close(fd);
        return -1;
    }

    // Configura os atributos da porta serial
    tty.c_iflag = IGNPAR;
    tty.c_oflag = 0;
    tty.c_lflag = 0;
    tty.c_lflag &= ~ECHO;

    // Configura a velocidade de transmissão
    cfsetospeed(&tty, baudrate);
    cfsetispeed(&tty, baudrate);

    // Configura os bits de dados
    tty.c_cflag = (tty.c_cflag & ~CSIZE);
    switch (dataBits) {
        case 5:
            tty.c_cflag |= CS5;
            break;
        case 6:
            tty.c_cflag |= CS6;
            break;
        case 7:
            tty.c_cflag |= CS7;
            break;
        case 8:
        default:
            tty.c_cflag |= CS8;
            break;
    }
    // Configura a paridade
    if (parity == 'E') {
        tty.c_cflag |= PARENB;
        tty.c_cflag &= ~PARODD;
    } else if (parity == 'O') {
        tty.c_cflag |= PARENB | PARODD;
    } else {
        tty.c_cflag &= ~PARENB;
    }
    // Configura o stop bit
    if (stopBits == 2) {
        tty.c_cflag |= CSTOPB;
    } else {
        tty.c_cflag &= ~CSTOPB;
    }

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        perror("Erro ao configurar atributos da porta serial");
        close(fd);
        return -1;
    }

    /* Enable RS485 mode: */
    struct serial_rs485 rs485conf;
    memset(&rs485conf, 0, sizeof(rs485conf));
    rs485conf.flags |= SER_RS485_ENABLED;
    rs485conf.flags |= SER_RS485_RTS_ON_SEND;
    rs485conf.flags &= ~(SER_RS485_RTS_AFTER_SEND);

    if (ioctl(fd, TIOCSRS485, &rs485conf) < 0) {
        perror("Erro ao definir RS485 mode");
        close(fd);
        return -1;
    }

    return fd;
}

// Função para fechar a porta serial (Linux)
void closeSerialPort(int fd) {
    close(fd);
    printf("Porta serial fechada.\n");
}

// Função para enviar dados pela porta serial (Linux)
int sendData(int fd, const uint8_t *data, uint16_t length) {
    ssize_t bytesSent = write(fd, data, length);
    if (bytesSent == -1) {
        perror("Erro ao enviar dados");
        return -1;
    }
    printf("Enviando dados: ");
    for (uint16_t i = 0; i < length; i++) {
        printf("%02X ", data[i]);
    }
    printf("\n");
    return (int)bytesSent;
}

// Função para receber dados da porta serial com timeout entre bytes usando select()
int receiveDataWithTimeout(int fd, uint8_t *buffer, uint16_t maxLength, long timeout_ms) {
    fd_set readfds;
    struct timeval tv;
    int ret;
    int bytesRead = 0;
    struct timeval lastByteTime, currentTime;

    FD_ZERO(&readfds);
    FD_SET(fd, &readfds);

    gettimeofday(&lastByteTime, NULL);

    while (bytesRead < maxLength) {
        tv.tv_sec = timeout_ms / 1000;
        tv.tv_usec = (timeout_ms % 1000) * 1000;

        ret = select(fd + 1, &readfds, NULL, NULL, &tv);
        if (ret == -1) {
            perror("Erro em select()");
            return -1;
        } else if (ret == 0) {
            break; // Timeout entre bytes
        } else {
            ssize_t n = read(fd, buffer + bytesRead, maxLength - bytesRead);
            if (n == -1) {
                perror("Erro ao ler da porta serial");
                return -1;
            }
            if (n == 0)
                continue;

            bytesRead += n;
            gettimeofday(&currentTime, NULL);
            lastByteTime = currentTime;
            printf("Dados recebidos: ");
            for (int i = 0; i < bytesRead; i++) {
                printf("%02X ", buffer[i]);
            }
            printf("\n");
        }
    }
    return bytesRead;
}

// Função para enviar comando de leitura de registrador(es)
bool sendReadRegistersCommand(int fd, uint8_t deviceAddress, uint16_t startAddress, uint16_t numRegisters) {
    
    uint8_t buffer[8];
    uint16_t crc;

    buffer[0] = deviceAddress;
    buffer[1] = FUNCTION_CODE_READ_HOLDING_REGISTERS;
    buffer[2] = (startAddress >> 8) & 0xFF;
    buffer[3] = startAddress & 0xFF;
    buffer[4] = (numRegisters >> 8) & 0xFF;
    buffer[5] = numRegisters & 0xFF;

    crc = calculateCRC16(buffer, 6);
    buffer[6] = crc & 0xFF;
    buffer[7] = (crc >> 8) & 0xFF;

    return sendData(fd, buffer, 8) == 8;

} // sendReadRegistersCommand

// Função para enviar comando de escrita em um único registrador
bool sendWriteSingleRegisterCommand(int fd, uint8_t deviceAddress, uint16_t registerAddress, uint16_t value) {
    
    uint8_t buffer[8];
    uint16_t crc;

    buffer[0] = deviceAddress;
    buffer[1] = FUNCTION_CODE_WRITE_SINGLE_REGISTER;
    buffer[2] = (registerAddress >> 8) & 0xFF;
    buffer[3] = registerAddress & 0xFF;
    buffer[4] = (value >> 8) & 0xFF;
    buffer[5] = value & 0xFF;

    crc = calculateCRC16(buffer, 6);
    buffer[6] = crc & 0xFF;
    buffer[7] = (crc >> 8) & 0xFF;

    return sendData(fd, buffer, 8) == 8;

} // sendWriteSingleRegisterCommand

// Função para enviar comando de escrita em múltiplos registradores
bool sendWriteMultipleRegistersCommand(int fd, uint8_t deviceAddress, uint16_t startAddress, uint16_t numRegisters, const uint16_t *values, uint16_t numBytes) {
    
    uint16_t crc;
    uint16_t commandLength = 9 + numBytes;
    uint8_t buffer[commandLength];

    buffer[0] = deviceAddress;
    buffer[1] = FUNCTION_CODE_WRITE_MULTIPLE_REGISTERS;
    buffer[2] = (startAddress >> 8) & 0xFF;
    buffer[3] = startAddress & 0xFF;
    buffer[4] = (numRegisters >> 8) & 0xFF;
    buffer[5] = numRegisters & 0xFF;
    buffer[6] = numBytes;

    for (uint16_t i = 0; i < numRegisters; i++) {
        buffer[7 + (i * 2)] = (values[i] >> 8) & 0xFF;
        buffer[7 + (i * 2) + 1] = values[i] & 0xFF;
    }
    crc = calculateCRC16(buffer, commandLength - 2);
    buffer[commandLength - 2] = crc & 0xFF;
    buffer[commandLength - 1] = (crc >> 8) & 0xFF;

    return sendData(fd, buffer, commandLength) == commandLength;

} // sendWriteMultipleRegistersCommand

// Função para receber resposta e verificar erros
bool receiveResponse(int fd, uint8_t expectedFunctionCode, uint8_t *buffer, uint16_t *length, uint8_t CmdSize) {

    uint16_t receivedCRC, calculatedCRC;
    int numBytesRead = receiveDataWithTimeout(fd, buffer, MAX_BUFFER_SIZE, 100);

    numBytesRead -= CmdSize;
    memcpy (buffer, buffer+CmdSize, numBytesRead);

    if (numBytesRead <= 0) {
        printf("Erro: Nenhuma resposta recebida ou erro na recepção.\n");
        return false;
    }

    *length = numBytesRead;
    if (numBytesRead < 5) {
        printf("Erro: Resposta muito curta.\n");
        return false;
    }

    // Verificação do endereço do dispositivo
    if (buffer[0] != MODBUS_ADDRESS) {
        printf("Erro: Endereço do dispositivo incorreto na resposta (Esperado: %02X, Recebido: %02X)\n", MODBUS_ADDRESS, buffer[0]);
        return false;
    }

    // Verificação do código de função
    if (buffer[1] == (expectedFunctionCode | 0x80)) {
        printf("Erro MODBUS: Código de função %02X com exceção %02X\n", expectedFunctionCode, buffer[2]);
        // Adicione aqui lógica para tratar códigos de exceção MODBUS
        return false;
    } else if (buffer[1] != expectedFunctionCode) {
        printf("Erro: Código de função incorreto na resposta (Esperado: %02X, Recebido: %02X)\n", expectedFunctionCode, buffer[1]);
        return false;
    }

    // Verificação do CRC
    receivedCRC = (buffer[numBytesRead - 1] << 8) | buffer[numBytesRead - 2];
    calculatedCRC = calculateCRC16(buffer, numBytesRead - 2);
    if (receivedCRC != calculatedCRC) {
        printf("Erro: Falha na verificação de CRC (Esperado: %04X, Recebido: %04X)\n", calculatedCRC, receivedCRC);
        return false;
    }

    return true;
} // receiveResponse

// Função para ler a tensão máxima do sistema e a corrente de carga nominal
bool readMaxVoltageAndChargeCurrent(int fd, uint8_t *systemVoltage, uint8_t *chargeCurrent) {
    uint8_t responseBuffer[MAX_BUFFER_SIZE];
    uint16_t responseLength;

    if (!sendReadRegistersCommand(fd, MODBUS_ADDRESS, REG_MAX_VOLTAGE_CHARGE_CURRENT, 1)) {
        printf("Erro ao enviar comando de leitura.\n");
        return false;
    }

    if (!receiveResponse(fd, FUNCTION_CODE_READ_HOLDING_REGISTERS, responseBuffer, &responseLength, SIZE_CMD_READ_HOLDING_REGISTER)) {
        printf("Erro ao receber resposta.\n");
        return false;
    }
    if (responseLength < 7) {
        printf("Erro: Resposta inesperada, tamanho da resposta menor que o esperado.\n");
        return false;
    }

    // Extrai os dados da resposta
    *systemVoltage = (responseBuffer[3] >> 4) & 0x0F;
    *chargeCurrent = responseBuffer[4] & 0x0F;

    return true;
}

// Função para ler o SOC da bateria
bool readBatterySOC(int fd, uint8_t *batterySOC) {
    uint8_t responseBuffer[MAX_BUFFER_SIZE];
    uint16_t responseLength;

    if (!sendReadRegistersCommand(fd, MODBUS_ADDRESS, REG_BATTERY_CAPACITY_SOC, 1)) {
        printf("Erro ao enviar comando de leitura do SOC da bateria.\n");
        return false;
    }

    if (!receiveResponse(fd, FUNCTION_CODE_READ_HOLDING_REGISTERS, responseBuffer, &responseLength, SIZE_CMD_READ_HOLDING_REGISTER)) {
        printf("Erro ao receber resposta.\n");
        return false;
    }
    if (responseLength < 7) {
        printf("Erro: Resposta inesperada, tamanho da resposta menor que o esperado.\n");
        return false;
    }

    // Extrai o SOC da resposta
    *batterySOC = responseBuffer[3];

    return true;
}

// Função para ler o estado da carga e o estado do carregamento
bool readLoadAndChargeState(int fd, uint8_t *loadState, uint8_t *chargeState) {
    uint8_t responseBuffer[MAX_BUFFER_SIZE];
    uint16_t responseLength;

    if (!sendReadRegistersCommand(fd, MODBUS_ADDRESS, REG_LOAD_STATE_CHARGE_STATE, 1)) {
        printf("Erro ao enviar comando de leitura.\n");
        return false;
    }

    if (!receiveResponse(fd, FUNCTION_CODE_READ_HOLDING_REGISTERS, responseBuffer, &responseLength,SIZE_CMD_READ_HOLDING_REGISTER)) {
        printf("Erro ao receber resposta.\n");
        return false;
    }
    if (responseLength < 7) {
        printf("Erro: Resposta inesperada, tamanho da resposta menor que o esperado.\n");
        return false;
    }

    // Extrai os dados da resposta
    *loadState = (responseBuffer[3] >> 7) & 0x01;
    *chargeState = responseBuffer[4];

    return true;
}

// Função para alterar o endereço do dispositivo
bool changeDeviceAddress(int fd, uint8_t newAddress) {
    uint8_t responseBuffer[MAX_BUFFER_SIZE];
    uint16_t responseLength;
    if (!sendWriteSingleRegisterCommand(fd, MODBUS_ADDRESS, REG_DEVICE_ADDRESS, newAddress)) {
        printf("Erro ao enviar comando de escrita para alterar endereço.\n");
        return false;
    }
    if (!receiveResponse(fd, FUNCTION_CODE_WRITE_SINGLE_REGISTER, responseBuffer, &responseLength,SIZE_CMD_WRITE_SINGLE_REGISTER)) {
        printf("Erro ao receber resposta ao alterar endereço.\n");
        return false;
    }
    if (responseLength < 8) {
        printf("Erro: Resposta inesperada, tamanho da resposta menor que o esperado.\n");
        return false;
    }
    if (responseBuffer[0] != newAddress) {
        printf("Erro: Endereço não alterado.\n");
        return false;
    }
    return true;
}

// Efetua a leitura da partição 0
bool readPartition0Data(int fd, Partition0Data *data) {
    uint8_t responseBuffer[256]; // Buffer para armazenar a resposta
    uint16_t responseLength;
    
    // Envia o comando para ler os registradores da partição 0 (endereços 0x000A a 0x001A)
    if (!sendReadRegistersCommand(fd, MODBUS_ADDRESS, REG_MAX_VOLTAGE_CHARGE_CURRENT, PARTITION_0_SIZE)) {
        // Use REG_MAX_VOLTAGE_CHARGE_CURRENT (0x000A) como endereço inicial
        printf("Erro ao enviar comando de leitura para a partição 0.\n");
        return false;
    }

    // Recebe a resposta
    if (!receiveResponse(fd, FUNCTION_CODE_READ_HOLDING_REGISTERS, responseBuffer, &responseLength,SIZE_CMD_READ_HOLDING_REGISTER)) {
        printf("Erro ao receber resposta da partição 0.\n");
        return false;
    }

    if (responseLength < 5 + PARTITION_0_SIZE*2) {
        printf("Erro: Resposta incompleta para a partição 0.\n");
        return false;
    }

    // Extrai os dados da resposta e preenche a estrutura
    data->MaxVoltage = responseBuffer[3];
    data->RatedCurrent = responseBuffer[4];
    data->RatedDischargeCurrent = responseBuffer[5];
    data->ProductType =  responseBuffer[6];

    // Copia os 16 bytes de ProductSpecification
    memcpy(data->ProductSpecification, &responseBuffer[7], 16);
    data->ProductSpecification[16] = 0;

    data->SoftwareVersion = (responseBuffer[23] << 24) | (responseBuffer[24] << 16) | (responseBuffer[25] << 8) | responseBuffer[26];
    data->HardwareVersion = (responseBuffer[27] << 24) | (responseBuffer[28] << 16) | (responseBuffer[29] << 8) | responseBuffer[30];
    data->ProductSerialNumber = (responseBuffer[31] << 24) | (responseBuffer[32] << 16) | (responseBuffer[33] << 8) | responseBuffer[34];
    data->DeviceAddress = (responseBuffer[35] << 8) | responseBuffer[36];

    return true;
} // readPartition0Data

// Efetua a leitura da partição 1
bool readPartition1Data(int fd, Partition1Data *data) {
    uint8_t responseBuffer[256]; // Buffer para armazenar a resposta
    uint16_t responseLength;

    // Envia o comando para ler os registradores da partição 1 (endereços 0x00FD a 0x012D)
    if (!sendReadRegistersCommand(fd, MODBUS_ADDRESS, REG_LOAD_STATE_CHARGE_STATE, PARTITION_1_SIZE)) { 
        printf("Erro ao enviar comando de leitura para a partição 1.\n");
        return false;
    }

    // Recebe a resposta
    if (!receiveResponse(fd, FUNCTION_CODE_READ_HOLDING_REGISTERS, responseBuffer, &responseLength, SIZE_CMD_READ_HOLDING_REGISTER)) {
        printf("Erro ao receber resposta da partição 1.\n");
        return false;
    }

    if (responseLength < 5 + PARTITION_1_SIZE * 2) { // Verifica se a resposta tem o tamanho esperado (1 byte addr + 1 byte func + 1 byte data length + 49 registros * 2 + 2 bytes crc)
        printf("Erro: Resposta incompleta para a partição 1. Esperado: %d, Recebido: %d\n", 5 + PARTITION_1_SIZE * 2, responseLength);
        return false;
    }

    // Extrai os dados da resposta e preenche a estrutura
    data->LoadState = responseBuffer[3];
    data->ChargeState = responseBuffer[4];
    data->Alarme_Failure = (responseBuffer[5] << 24) | (responseBuffer[6] << 16) | (responseBuffer[7] << 8) | responseBuffer[8];  // Correção: Falha e Alarme
    data->BatterySOC = (responseBuffer[9] << 8) | responseBuffer[10];
    data->BatteryVoltage = (responseBuffer[11] << 8) | responseBuffer[12];
    data->ChargeCurrent = (responseBuffer[13] << 8) | responseBuffer[14];
    data->DeviceTemperature = responseBuffer[15]; 
    data->BatteryTemperature = responseBuffer[16];
    data->LoadVoltage = (responseBuffer[17] << 8) | responseBuffer[18];
    data->LoadCurrent = (responseBuffer[19] << 8) | responseBuffer[20];
    data->LoadPower = (responseBuffer[21] << 8) | responseBuffer[22];
    data->SolarPanelVoltage = (responseBuffer[23] << 8) | responseBuffer[24];
    data->SolarPanelCurrent = (responseBuffer[25] << 8) | responseBuffer[26];
    data->ChargePower = (responseBuffer[27] << 8) | responseBuffer[28];
    data->LoadOnOff = (responseBuffer[29] <<8) | responseBuffer[30];
    data->MinBatteryVoltageToday = (responseBuffer[31] << 8) | responseBuffer[32];
    data->MaxBatteryVoltageToday = (responseBuffer[33] << 8) | responseBuffer[34];
    data->MaxChargeCurrentToday = (responseBuffer[35] << 8) | responseBuffer[36];  
    data->MaxDischargeCurrentToday = (responseBuffer[37] << 8) | responseBuffer[38];
    data->MaxChargePowerToday = (responseBuffer[39] << 8) | responseBuffer[40];
    data->MaxDischargePowerToday = (responseBuffer[41] << 8) | responseBuffer[42];
    data->ChargeAmpereHourToday = (responseBuffer[43] << 8) | responseBuffer[44];
    data->DischargeAmpereHourToday = (responseBuffer[45] << 8) | responseBuffer[46];   
    data->GeneratingCapacityToday =  (responseBuffer[47] << 8) | responseBuffer[48];
    data->ElectricityConsumedToday = (responseBuffer[49] << 8) | responseBuffer[50];
    data->TotalOperatingDays = (responseBuffer[51] << 8) | responseBuffer[52];
    data->TotalOverdischargetimes = (responseBuffer[53] << 8) | responseBuffer[54];
    data->TotalBatteryChargeTimes = (responseBuffer[55] << 8) | responseBuffer[56];
    data->TotalBatteryChargeAH = (responseBuffer[57] << 24) | (responseBuffer[58] << 16) | (responseBuffer[59] << 8) | responseBuffer[60];
    data->TotalBatteryDischargeAH = (responseBuffer[61] << 24) | (responseBuffer[62] << 16) | (responseBuffer[63] << 8) | responseBuffer[64];
    data->AccumulatedGeneratingCapacity = (responseBuffer[65] << 24) | (responseBuffer[66] << 16) | (responseBuffer[67] << 8) | responseBuffer[68];
    data->AccumulatedElectricityConsuption = (responseBuffer[69] << 24) | (responseBuffer[70] << 16) | (responseBuffer[71] << 8) | responseBuffer[72];
    // salta os 2 endereços (73 e 74) - Load state e charge state ja foram lidos em 0xFD
    // salta os 4 endereços (75, 76, 77 e 78) de indicação de falha e alarme que já foram lidos no endereço 5a 8
    data->MaxBatteryTemperatureToday = (responseBuffer[79] << 8) | responseBuffer[80];
    data->MinBatteryTemperatureToday = (responseBuffer[81] << 8) | responseBuffer[82];
    data->TotalLoadOperationTime = (responseBuffer[83] << 24) | (responseBuffer[84] << 16) | (responseBuffer[85] << 8) | responseBuffer[86];
    data->Onduration = (responseBuffer[87] << 8) | responseBuffer[88];
    data->OffDuration = (responseBuffer[89] << 8) | responseBuffer[90];
    data->LightingIndex = (responseBuffer[91] << 8) | responseBuffer[92];
    data->EnergyConsumption = (responseBuffer[93] << 8) | responseBuffer[94];
    data->SystemHealthIndex = (responseBuffer[95] << 8) | responseBuffer[96];
    data->ChargeDurationOnDay = (responseBuffer[97] << 8) | responseBuffer[98];
    data->NightDuration = (responseBuffer[99] << 8) | responseBuffer[100];

    return true;

} // readPartition1Data






